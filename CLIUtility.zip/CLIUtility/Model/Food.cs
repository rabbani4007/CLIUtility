namespace CLIUtility
{
    public class Food
    {
        public string food_name { get; set; }
        public int serving_qty { get; set; }
        public string serving_unit { get; set; }
       
        public double nf_calories { get; set; }


        public double nf_protein { get; set; }
        public double nf_potassium { get; set; }
       
    }


}
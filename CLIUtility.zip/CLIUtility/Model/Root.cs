using System.Collections.Generic;

namespace CLIUtility
{
    public class Root
    {
        public List<Food> foods { get; set; }
    }
}